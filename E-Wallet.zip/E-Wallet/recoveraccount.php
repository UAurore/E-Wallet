<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sent an Email</title>
</head>
<body>
    <h1>Sent you an Email</h1>
    <p>We just sent you an email, Please check your email and follow the instruction to reset your password</p>
</body>
</html>