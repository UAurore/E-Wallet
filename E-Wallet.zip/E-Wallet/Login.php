<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <title>Login</title>
</head>
<body>
<fieldset style="width:50%;" class="container">
    <h2>Welcome to your account</h2>
    <form action="index.php" method="post">
        Phone: <input type="number" name="phone" id=""><br><br>
        Password: <input type="password" name="password" id=""><br><br>
        <input type="submit" value="Login">
        <a href="http://forgotpassword.html">Forgot Password</a>
    </form>
    </fieldset>
</body>
</html>