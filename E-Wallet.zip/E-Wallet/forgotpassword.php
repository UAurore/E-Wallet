<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recover account</title>
</head>
<body>
<fieldset style="width:50%;">
    <form action="recoveraccount.php" method="post">
        <h1>Reset your password</h1>
        Email: <input type="email" name="email"><br><br>
        Phone: <input type="number" name="phone"><br><br>
        <input type="submit" value="Send">
    </form>
    </fieldset> 
</body>
</html>